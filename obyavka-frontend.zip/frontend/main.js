const API_URL = "https://your-backend-url.onrender.com/api";

document.getElementById("app").innerHTML = "<p>Frontend подключён. Скоро здесь появятся объявления.</p>";
